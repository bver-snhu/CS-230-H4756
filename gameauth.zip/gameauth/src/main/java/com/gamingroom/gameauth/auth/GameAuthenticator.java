/* Ben Verrill
CS - 230 / 21EW4 Operating Platforms
3/25/2021
*/
package com.gamingroom.gameauth.auth;


import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;
 
import java.util.Map;
import java.util.Optional;
import java.util.Set;
 
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
 
public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> 
{
		
	private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "player", ImmutableSet.of("PLAYER"), //Add role for PLAYER
        "admin", ImmutableSet.of("ADMIN", "USER")
    );
 
    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException 
    {
    	// Check if username has role associated with it, contained in VALID_USERS, and that the given password matches "password". If so return new GameUser object
    	// with username and role. If not, do not return authenticated object.
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) 
        {
        	return Optional.of(new GameUser(credentials.getUsername(), VALID_USERS.get(credentials.getUsername())));

        }
        return Optional.empty();
    }
}
